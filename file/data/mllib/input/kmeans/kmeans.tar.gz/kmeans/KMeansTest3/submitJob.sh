    #!/usr/bin/env bash  
    spark-submit  \
--class mllib.KMeansTest3 \
--master spark://219.219.220.149:7077 \
--executor-memory 512M \
--total-executor-cores 20 KMeansTest3.jar

