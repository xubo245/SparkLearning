    #!/usr/bin/env bash  
    spark-submit  \
--class mllib.KMeansTest4ByIBmSaveAsFileCluster \
--master spark://219.219.220.149:7077 \
--executor-memory 512M \
--total-executor-cores 20 KMeansTest4ByIBmSaveAsFileCluster.jar "/xubo/spark/data/mllib/kmeans/WholesaleCustomersDataTrain1.txt" "/xubo/spark/data/mllib/kmeans/WholesaleCustomersDataTest1.txt" 8 30 3

